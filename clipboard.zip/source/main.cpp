/*  Manipulate the clipboard from the command line.
   Copyright (C) 1989, 1990, 1991, 1992, 1993 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 2, or (at your option) any
   later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/**
  *
  *   This program is a simple utility for working with the Clipboard
  * under Windows.
  *
  *   There are several modes this utility will operate in, depending
  * on the command line arguments.
  *
  *  Version 1.3
  *
  *  Steve Kemp
  *  <skx@tardis.ed.ac.uk>
  *
  */


#include "stdafx.h"
#include "Clipboard.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdiostr.h>
#include <string>
#include "getopt.h"


/**
  * Options that this program accepts, either in long form, or in short.
  */
struct option clipboardOptions[] = 
	{
		{"pwd", no_argument, NULL, 'p'},
		{"version", no_argument, NULL, 'v'},
		{"help", no_argument, NULL, 'h'},
		{"license", no_argument, NULL, 'l'},
		{0, 0, 0, 0}
	};

/**
 *  Entry point to the code
 */
int main( int argc, char *argv[] )
{
	int retval;
	int opt_index = 1;

	retval = getopt_long (argc, argv, "pvhl", clipboardOptions, &opt_index);

	while (retval != EOF) 
	{
		switch (retval) 
		{
			case 'p': /* Copy PWD to the clipboard*/
				// Set the clipboard to the PWD 
				CopyPWDToClipboard();
				exit( 1 );
				break;
			case 'l': /*  Show the GNU License */
				showGNULicense();
				exit( 1 );
				break;
			case 'v':
				showVersion();
				exit( 1 );
				break;
			case 'h':
				showHelp();
				exit( 1 );
				break;
		}
		retval = getopt_long (argc, argv, "pvh", 
			      clipboardOptions, &opt_index);
	
	}

	if ( optind == argc )
	{
		// Show the contents
		ShowClipboard();
	}
	else
	{
		// Copy specified file
        if ( strcmp( argv[ optind ], "-" ) == 0 )
        {
            CopySTDINToClipboard( );
        }
        else
        {
            CopyFileToClipboard( argv[ optind] );
        }
	}

	return 0;
}

/**
  * Dump the contents of the clipboard to the console.
  */
void ShowClipboard()
{
	unsigned long size;
	CClipboard::GetTextLength( &size );

	char *text = (char *)malloc( size );
	if ( !text )
	{
		printf( "Failed to allocated memory\n\n" );
		return;
	}

	CClipboard::GetText( text, size );
	printf( "%s\n", text );
	free( text );
}

/**
  * Copy the current working directory to the clipboard.
  */
void CopyPWDToClipboard( )
{
	char pwd[ MAX_PATH + 1 ];
	GetCurrentDirectory( MAX_PATH, pwd );
	CClipboard::SetText( pwd );
}

void CopySTDINToClipboard()
{
    stdiostream input( stdin );
	std::string text;

	char *buffer[ 1024];
	int buffer_size = 1024;
    while( input.getline( (char*)buffer, buffer_size ) )
    {
        text += std::string( (char*)buffer );
		text += "\n";
    }

	CClipboard::SetText( ((char*)text.c_str()) );
}


/**
  * Copy the contents of a file to the clipboard.
  */
void CopyFileToClipboard( char *fileName )
{
	unsigned int size;
	FILE *f1;
	char *buffer;

	// Get the file size.
	size = getFileSize( fileName );

	// Open the file
	f1 = fopen( fileName, "rb" );
	if ( f1 == NULL )
	{
	    printf( "Error opening file %s, terminating.\n", fileName );
	    exit( -1 );
	}

	// Allocate memory to read in the file.
	buffer = (char *)malloc( size + 1 );
	if ( buffer == NULL )
	{
		printf( "Error allocating memory.\n" );
		fclose( f1 );
		exit( - 1 );
	}

	
    // Read in the input file
    if ( fread( buffer, 1, size, f1 ) != size)
	{
      printf( "Couldn't read all of input file %s.\n", fileName );
      free( buffer );
      fclose( f1 );
	  exit( -1 );
	}

	CClipboard::SetText( buffer );
	free( buffer );
	fclose( f1 );
}


/**
  *  Find the size of a file.
  */
int getFileSize( char *fileName )
{
  FILE *in;

  in = fopen( fileName, "rb" );
  if ( in == NULL )
  {
    printf( "Error opening file %s, terminating.\n", fileName );
    exit( -1 );
  }

  // Get the size of the file
  if ( fseek( in, 0, SEEK_END ) != 0 )
  {
    printf( "Error seeking on file %s.\n", fileName );
    exit( -1 );
  }

  // Get the current position
  int fileLength = ftell( in );

  // close the file
  fclose( in );

  return( fileLength );
}


/**
  * Show help information.
  */
void showHelp()
{
	showVersion();
	printf( "\n\n" );
	printf( "Usage:  Clipboard [options] [file]\n" );
	printf( " --pwd     [p] Copy the current working directory to the clipboard\n" );
	printf( " --help    [h] Show this help\n" );
	printf( " --version [v] Show the version number\n" );
	printf( " --license [l] Show the GNU License\n" );
	printf( "\n If a filename is specified rather than \"--pwd\" its contents will be\n" );
	printf( "copied to the clipboard, otherwise the clipboard contents will be displayed\n" );
    printf(" \nUse '-' to copy the input from stdin to the clipboard\n\n" );
	printf( "Clipboard is distributed in the hope it will be usefull, but\n" );
	printf( "with NO Warrantie of any kind.  For more information please\n" );
	printf( "run \"clipboard --license\"\n" );
}

/**
  * Show the version information.
  */
void showVersion( )
{
	printf( "Clipboard version %s\n", VERSION_STRING );
}

void showGNULicense()
{
	printf( "%s", "		    GNU GENERAL PUBLIC LICENSE\n" );
printf( "%s", "		       Version 2, June 1991\n" );
printf( "%s", "\n" );
printf( "%s", " Copyright (C) 1989, 1991 Free Software Foundation, Inc.\n" );
printf( "%s", "                       59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n" );
printf( "%s", " Everyone is permitted to copy and distribute verbatim copies\n" );
printf( "%s", " of this license document, but changing it is not allowed.\n" );
printf( "%s", "\n" );
printf( "%s", "			    Preamble\n" );
printf( "%s", "\n" );
printf( "%s", "  The licenses for most software are designed to take away your\n" );
printf( "%s", "freedom to share and change it.  By contrast, the GNU General Public\n" );
printf( "%s", "License is intended to guarantee your freedom to share and change free\n" );
printf( "%s", "software--to make sure the software is free for all its users.  This\n" );
printf( "%s", "General Public License applies to most of the Free Software\n" );
printf( "%s", "Foundation's software and to any other program whose authors commit to\n" );
printf( "%s", "using it.  (Some other Free Software Foundation software is covered by\n" );
printf( "%s", "the GNU Library General Public License instead.)  You can apply it to\n" );
printf( "%s", "your programs, too.\n" );
printf( "%s", "\n" );
printf( "%s", "  When we speak of free software, we are referring to freedom, not\n" );
printf( "%s", "price.  Our General Public Licenses are designed to make sure that you\n" );
printf( "%s", "have the freedom to distribute copies of free software (and charge for\n" );
printf( "%s", "this service if you wish), that you receive source code or can get it\n" );
printf( "%s", "if you want it, that you can change the software or use pieces of it\n" );
printf( "%s", "in new free programs; and that you know you can do these things.\n" );
printf( "%s", "\n" );
printf( "%s", "  To protect your rights, we need to make restrictions that forbid\n" );
printf( "%s", "anyone to deny you these rights or to ask you to surrender the rights.\n" );
printf( "%s", "These restrictions translate to certain responsibilities for you if you\n" );
printf( "%s", "distribute copies of the software, or if you modify it.\n" );
printf( "%s", "\n" );
printf( "%s", "  For example, if you distribute copies of such a program, whether\n" );
printf( "%s", "gratis or for a fee, you must give the recipients all the rights that\n" );
printf( "%s", "you have.  You must make sure that they, too, receive or can get the\n" );
printf( "%s", "source code.  And you must show them these terms so they know their\n" );
printf( "%s", "rights.\n" );
printf( "%s", "\n" );
printf( "%s", "  We protect your rights with two steps: (1) copyright the software, and\n" );
printf( "%s", "(2) offer you this license which gives you legal permission to copy,\n" );
printf( "%s", "distribute and/or modify the software.\n" );
printf( "%s", "\n" );
printf( "%s", "  Also, for each author's protection and ours, we want to make certain\n" );
printf( "%s", "that everyone understands that there is no warranty for this free\n" );
printf( "%s", "software.  If the software is modified by someone else and passed on, we\n" );
printf( "%s", "want its recipients to know that what they have is not the original, so\n" );
printf( "%s", "that any problems introduced by others will not reflect on the original\n" );
printf( "%s", "authors' reputations.\n" );
printf( "%s", "\n" );
printf( "%s", "  Finally, any free program is threatened constantly by software\n" );
printf( "%s", "patents.  We wish to avoid the danger that redistributors of a free\n" );
printf( "%s", "program will individually obtain patent licenses, in effect making the\n" );
printf( "%s", "program proprietary.  To prevent this, we have made it clear that any\n" );
printf( "%s", "patent must be licensed for everyone's free use or not licensed at all.\n" );
printf( "%s", "\n" );
printf( "%s", "  The precise terms and conditions for copying, distribution and\n" );
printf( "%s", "modification follow.\n" );
printf( "%s", "\n" );
printf( "%s", "		    GNU GENERAL PUBLIC LICENSE\n" );
printf( "%s", "   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n" );
printf( "%s", "\n" );
printf( "%s", "  0. This License applies to any program or other work which contains\n" );
printf( "%s", "a notice placed by the copyright holder saying it may be distributed\n" );
printf( "%s", "under the terms of this General Public License.  The \"Program\", below,\n" );
printf( "%s", "refers to any such program or work, and a \"work based on the Program\"\n" );
printf( "%s", "means either the Program or any derivative work under copyright law:\n" );
printf( "%s", "that is to say, a work containing the Program or a portion of it,\n" );
printf( "%s", "either verbatim or with modifications and/or translated into another\n" );
printf( "%s", "language.  (Hereinafter, translation is included without limitation in\n" );
printf( "%s", "the term \"modification\".)  Each licensee is addressed as \"you\".\n" );
printf( "%s", "\n" );
printf( "%s", "Activities other than copying, distribution and modification are not\n" );
printf( "%s", "covered by this License; they are outside its scope.  The act of\n" );
printf( "%s", "running the Program is not restricted, and the output from the Program\n" );
printf( "%s", "is covered only if its contents constitute a work based on the\n" );
printf( "%s", "Program (independent of having been made by running the Program).\n" );
printf( "%s", "Whether that is true depends on what the Program does.\n" );
printf( "%s", "\n" );
printf( "%s", "  1. You may copy and distribute verbatim copies of the Program's\n" );
printf( "%s", "source code as you receive it, in any medium, provided that you\n" );
printf( "%s", "conspicuously and appropriately publish on each copy an appropriate\n" );
printf( "%s", "copyright notice and disclaimer of warranty; keep intact all the\n" );
printf( "%s", "notices that refer to this License and to the absence of any warranty;\n" );
printf( "%s", "and give any other recipients of the Program a copy of this License\n" );
printf( "%s", "along with the Program.\n" );
printf( "%s", "\n" );
printf( "%s", "You may charge a fee for the physical act of transferring a copy, and\n" );
printf( "%s", "you may at your option offer warranty protection in exchange for a fee.\n" );
printf( "%s", "\n" );
printf( "%s", "  2. You may modify your copy or copies of the Program or any portion\n" );
printf( "%s", "of it, thus forming a work based on the Program, and copy and\n" );
printf( "%s", "distribute such modifications or work under the terms of Section 1\n" );
printf( "%s", "above, provided that you also meet all of these conditions:\n" );
printf( "%s", "\n" );
printf( "%s", "    a) You must cause the modified files to carry prominent notices\n" );
printf( "%s", "    stating that you changed the files and the date of any change.\n" );
printf( "%s", "\n" );
printf( "%s", "    b) You must cause any work that you distribute or publish, that in\n" );
printf( "%s", "    whole or in part contains or is derived from the Program or any\n" );
printf( "%s", "    part thereof, to be licensed as a whole at no charge to all third\n" );
printf( "%s", "    parties under the terms of this License.\n" );
printf( "%s", "\n" );
printf( "%s", "    c) If the modified program normally reads commands interactively\n" );
printf( "%s", "    when run, you must cause it, when started running for such\n" );
printf( "%s", "    interactive use in the most ordinary way, to print or display an\n" );
printf( "%s", "    announcement including an appropriate copyright notice and a\n" );
printf( "%s", "    notice that there is no warranty (or else, saying that you provide\n" );
printf( "%s", "    a warranty) and that users may redistribute the program under\n" );
printf( "%s", "    these conditions, and telling the user how to view a copy of this\n" );
printf( "%s", "    License.  (Exception: if the Program itself is interactive but\n" );
printf( "%s", "    does not normally print such an announcement, your work based on\n" );
printf( "%s", "    the Program is not required to print an announcement.)\n" );
printf( "%s", "\n" );
printf( "%s", "These requirements apply to the modified work as a whole.  If\n" );
printf( "%s", "identifiable sections of that work are not derived from the Program,\n" );
printf( "%s", "and can be reasonably considered independent and separate works in\n" );
printf( "%s", "themselves, then this License, and its terms, do not apply to those\n" );
printf( "%s", "sections when you distribute them as separate works.  But when you\n" );
printf( "%s", "distribute the same sections as part of a whole which is a work based\n" );
printf( "%s", "on the Program, the distribution of the whole must be on the terms of\n" );
printf( "%s", "this License, whose permissions for other licensees extend to the\n" );
printf( "%s", "entire whole, and thus to each and every part regardless of who wrote it.\n" );
printf( "%s", "\n" );
printf( "%s", "Thus, it is not the intent of this section to claim rights or contest\n" );
printf( "%s", "your rights to work written entirely by you; rather, the intent is to\n" );
printf( "%s", "exercise the right to control the distribution of derivative or\n" );
printf( "%s", "collective works based on the Program.\n" );
printf( "%s", "\n" );
printf( "%s", "In addition, mere aggregation of another work not based on the Program\n" );
printf( "%s", "with the Program (or with a work based on the Program) on a volume of\n" );
printf( "%s", "a storage or distribution medium does not bring the other work under\n" );
printf( "%s", "the scope of this License.\n" );
printf( "%s", "\n" );
printf( "%s", "  3. You may copy and distribute the Program (or a work based on it,\n" );
printf( "%s", "under Section 2) in object code or executable form under the terms of\n" );
printf( "%s", "Sections 1 and 2 above provided that you also do one of the following:\n" );
printf( "%s", "\n" );
printf( "%s", "    a) Accompany it with the complete corresponding machine-readable\n" );
printf( "%s", "    source code, which must be distributed under the terms of Sections\n" );
printf( "%s", "    1 and 2 above on a medium customarily used for software interchange; or,\n" );
printf( "%s", "\n" );
printf( "%s", "    b) Accompany it with a written offer, valid for at least three\n" );
printf( "%s", "    years, to give any third party, for a charge no more than your\n" );
printf( "%s", "    cost of physically performing source distribution, a complete\n" );
printf( "%s", "    machine-readable copy of the corresponding source code, to be\n" );
printf( "%s", "    distributed under the terms of Sections 1 and 2 above on a medium\n" );
printf( "%s", "    customarily used for software interchange; or,\n" );
printf( "%s", "\n" );
printf( "%s", "    c) Accompany it with the information you received as to the offer\n" );
printf( "%s", "    to distribute corresponding source code.  (This alternative is\n" );
printf( "%s", "    allowed only for noncommercial distribution and only if you\n" );
printf( "%s", "    received the program in object code or executable form with such\n" );
printf( "%s", "    an offer, in accord with Subsection b above.)\n" );
printf( "%s", "\n" );
printf( "%s", "The source code for a work means the preferred form of the work for\n" );
printf( "%s", "making modifications to it.  For an executable work, complete source\n" );
printf( "%s", "code means all the source code for all modules it contains, plus any\n" );
printf( "%s", "associated interface definition files, plus the scripts used to\n" );
printf( "%s", "control compilation and installation of the executable.  However, as a\n" );
printf( "%s", "special exception, the source code distributed need not include\n" );
printf( "%s", "anything that is normally distributed (in either source or binary\n" );
printf( "%s", "form) with the major components (compiler, kernel, and so on) of the\n" );
printf( "%s", "operating system on which the executable runs, unless that component\n" );
printf( "%s", "itself accompanies the executable.\n" );
printf( "%s", "\n" );
printf( "%s", "If distribution of executable or object code is made by offering\n" );
printf( "%s", "access to copy from a designated place, then offering equivalent\n" );
printf( "%s", "access to copy the source code from the same place counts as\n" );
printf( "%s", "distribution of the source code, even though third parties are not\n" );
printf( "%s", "compelled to copy the source along with the object code.\n" );
printf( "%s", "\n" );
printf( "%s", "  4. You may not copy, modify, sublicense, or distribute the Program\n" );
printf( "%s", "except as expressly provided under this License.  Any attempt\n" );
printf( "%s", "otherwise to copy, modify, sublicense or distribute the Program is\n" );
printf( "%s", "void, and will automatically terminate your rights under this License.\n" );
printf( "%s", "However, parties who have received copies, or rights, from you under\n" );
printf( "%s", "this License will not have their licenses terminated so long as such\n" );
printf( "%s", "parties remain in full compliance.\n" );
printf( "%s", "\n" );
printf( "%s", "  5. You are not required to accept this License, since you have not\n" );
printf( "%s", "signed it.  However, nothing else grants you permission to modify or\n" );
printf( "%s", "distribute the Program or its derivative works.  These actions are\n" );
printf( "%s", "prohibited by law if you do not accept this License.  Therefore, by\n" );
printf( "%s", "modifying or distributing the Program (or any work based on the\n" );
printf( "%s", "Program), you indicate your acceptance of this License to do so, and\n" );
printf( "%s", "all its terms and conditions for copying, distributing or modifying\n" );
printf( "%s", "the Program or works based on it.\n" );
printf( "%s", "\n" );
printf( "%s", "  6. Each time you redistribute the Program (or any work based on the\n" );
printf( "%s", "Program), the recipient automatically receives a license from the\n" );
printf( "%s", "original licensor to copy, distribute or modify the Program subject to\n" );
printf( "%s", "these terms and conditions.  You may not impose any further\n" );
printf( "%s", "restrictions on the recipients' exercise of the rights granted herein.\n" );
printf( "%s", "You are not responsible for enforcing compliance by third parties to\n" );
printf( "%s", "this License.\n" );
printf( "%s", "\n" );
printf( "%s", "  7. If, as a consequence of a court judgment or allegation of patent\n" );
printf( "%s", "infringement or for any other reason (not limited to patent issues),\n" );
printf( "%s", "conditions are imposed on you (whether by court order, agreement or\n" );
printf( "%s", "otherwise) that contradict the conditions of this License, they do not\n" );
printf( "%s", "excuse you from the conditions of this License.  If you cannot\n" );
printf( "%s", "distribute so as to satisfy simultaneously your obligations under this\n" );
printf( "%s", "License and any other pertinent obligations, then as a consequence you\n" );
printf( "%s", "may not distribute the Program at all.  For example, if a patent\n" );
printf( "%s", "license would not permit royalty-free redistribution of the Program by\n" );
printf( "%s", "all those who receive copies directly or indirectly through you, then\n" );
printf( "%s", "the only way you could satisfy both it and this License would be to\n" );
printf( "%s", "refrain entirely from distribution of the Program.\n" );
printf( "%s", "\n" );
printf( "%s", "If any portion of this section is held invalid or unenforceable under\n" );
printf( "%s", "any particular circumstance, the balance of the section is intended to\n" );
printf( "%s", "apply and the section as a whole is intended to apply in other\n" );
printf( "%s", "circumstances.\n" );
printf( "%s", "\n" );
printf( "%s", "It is not the purpose of this section to induce you to infringe any\n" );
printf( "%s", "patents or other property right claims or to contest validity of any\n" );
printf( "%s", "such claims; this section has the sole purpose of protecting the\n" );
printf( "%s", "integrity of the free software distribution system, which is\n" );
printf( "%s", "implemented by public license practices.  Many people have made\n" );
printf( "%s", "generous contributions to the wide range of software distributed\n" );
printf( "%s", "through that system in reliance on consistent application of that\n" );
printf( "%s", "system; it is up to the author/donor to decide if he or she is willing\n" );
printf( "%s", "to distribute software through any other system and a licensee cannot\n" );
printf( "%s", "impose that choice.\n" );
printf( "%s", "\n" );
printf( "%s", "This section is intended to make thoroughly clear what is believed to\n" );
printf( "%s", "be a consequence of the rest of this License.\n" );
printf( "%s", "\n" );
printf( "%s", "  8. If the distribution and/or use of the Program is restricted in\n" );
printf( "%s", "certain countries either by patents or by copyrighted interfaces, the\n" );
printf( "%s", "original copyright holder who places the Program under this License\n" );
printf( "%s", "may add an explicit geographical distribution limitation excluding\n" );
printf( "%s", "those countries, so that distribution is permitted only in or among\n" );
printf( "%s", "countries not thus excluded.  In such case, this License incorporates\n" );
printf( "%s", "the limitation as if written in the body of this License.\n" );
printf( "%s", "\n" );
printf( "%s", "  9. The Free Software Foundation may publish revised and/or new versions\n" );
printf( "%s", "of the General Public License from time to time.  Such new versions will\n" );
printf( "%s", "be similar in spirit to the present version, but may differ in detail to\n" );
printf( "%s", "address new problems or concerns.\n" );
printf( "%s", "\n" );
printf( "%s", "Each version is given a distinguishing version number.  If the Program\n" );
printf( "%s", "specifies a version number of this License which applies to it and \"any\n" );
printf( "%s", "later version\", you have the option of following the terms and conditions\n" );
printf( "%s", "either of that version or of any later version published by the Free\n" );
printf( "%s", "Software Foundation.  If the Program does not specify a version number of\n" );
printf( "%s", "this License, you may choose any version ever published by the Free Software\n" );
printf( "%s", "Foundation.\n" );
printf( "%s", "\n" );
printf( "%s", "  10. If you wish to incorporate parts of the Program into other free\n" );
printf( "%s", "programs whose distribution conditions are different, write to the author\n" );
printf( "%s", "to ask for permission.  For software which is copyrighted by the Free\n" );
printf( "%s", "Software Foundation, write to the Free Software Foundation; we sometimes\n" );
printf( "%s", "make exceptions for this.  Our decision will be guided by the two goals\n" );
printf( "%s", "of preserving the free status of all derivatives of our free software and\n" );
printf( "%s", "of promoting the sharing and reuse of software generally.\n" );
printf( "%s", "\n" );
printf( "%s", "			    NO WARRANTY\n" );
printf( "%s", "\n" );
printf( "%s", "  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\n" );
printf( "%s", "FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN\n" );
printf( "%s", "OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\n" );
printf( "%s", "PROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED\n" );
printf( "%s", "OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\n" );
printf( "%s", "MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS\n" );
printf( "%s", "TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE\n" );
printf( "%s", "PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\n" );
printf( "%s", "REPAIR OR CORRECTION.\n" );
printf( "%s", "\n" );
printf( "%s", "  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\n" );
printf( "%s", "WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR\n" );
printf( "%s", "REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,\n" );
printf( "%s", "INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING\n" );
printf( "%s", "OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED\n" );
printf( "%s", "TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY\n" );
printf( "%s", "YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER\n" );
printf( "%s", "PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE\n" );
printf( "%s", "POSSIBILITY OF SUCH DAMAGES.\n" );
printf( "%s", "\n" );
printf( "%s", "		     END OF TERMS AND CONDITIONS\n" );
}
